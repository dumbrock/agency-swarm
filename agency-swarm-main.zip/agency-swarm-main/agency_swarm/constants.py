DEFAULT_MODEL = "gpt-4o"
DEFAULT_MODEL_MINI = "gpt-4o-mini"
