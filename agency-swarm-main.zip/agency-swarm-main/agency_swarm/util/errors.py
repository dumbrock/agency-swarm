class RefusalError(Exception):
    pass
